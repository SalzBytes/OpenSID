<?php
// -------------------------------------------------------------------------
//
// Letakkan username, password dan database sebetulnya di file ini.
// File ini JANGAN di-commit ke GIT. TAMBAHKAN di .gitignore
// -------------------------------------------------------------------------

// Data Konfigurasi MySQL yang disesuaikan

$db['default']['hostname'] = 'localhost';
$db['default']['username'] = 'root';
$db['default']['password'] = 'eyJpdiI6Img0Mi9aVmtNYVY2dUMxS3YyQ2ZKalE9PSIsInZhbHVlIjoiOWUxQWVYeU5MT1lIcW5oZjlPU0JaZz09IiwibWFjIjoiMTZhZjUwZDdmYmQyMmJjNjkzODM1Yjc4OTBjZDhiZjQ5NDA4ZjE5MzU1NWFmYTdiNDU2NzI4ZjAyZDkzZTRhZCIsInRhZyI6IiJ9';
$db['default']['port']     = 3306;
$db['default']['dbcollat'] = 'utf8mb4_general_ci';
$db['default']['database'] = 'opensid-issue#9065';

// $db['opensid-gabungan'] = [
//     'hostname'     => 'localhost',
//     'username'     => 'root',
//     'password'     => '',
//     'database'     => 'opensid-tabanan-buwit',
//     'port'         => 3306,
//     'stricton'     => true,
//     'dbdriver'     => 'mysqli',
//     'dbprefix'     => '',
//     'pconnect'     => false,
//     'db_debug'     => true,
//     'cache_on'     => false,
//     'cachedir'     => '',
//     'char_set'     => 'utf8mb4',
//     'dbcollat'     => 'utf8mb4_general_ci',
//     'swap_pre'     => '',
//     'autoinit'     => false,
//     'encrypt'      => false,
//     'compress'     => false,
//     'failover'     => [],
//     'save_queries' => true,
//     'options'      => [
//         PDO::ATTR_EMULATE_PREPARES => true,
//     ],
// ];

/*
| Untuk setting koneksi database 'Strict Mode'
| Sesuaikan dengan ketentuan hosting
*/
$db['default']['stricton'] = true;

/*
| Konfigurasi options digunakan untuk menyisipkan opsi tambahan
| saat mengatur koneksi ke database.
*/
$db['default']['options'] = [
    PDO::ATTR_EMULATE_PREPARES => true,
];